<p align="center">
<a href="https://telegra.ph/file/f0ad06cf797adc9a1a6a5.jpg"><img src="https://telegra.ph/file/f0ad06cf797adc9a1a6a5.jpg"</a>
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Orbitron&size=28&duration=3000&pause=1000&color=964B00&width=456&lines=IKYBOTMD;CREATED+BY+RIZKI+IRFAN" alt="Typing SVG" /></a>
<img src="https://img.shields.io/badge/rating-★★★★★-brightgreen"/>
<img src="https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges"/>
<a href="https://github.com/rizkiwibu/IKY-BOT-WHATSAPP-OFFICIAL-"><img src="https://img.shields.io/github/watchers/Takashi-Kemii/Kiku.svg"</a>
<a href="https://github.com/rizkiwibu/IKY-BOT-WHATSAPP-OFFICIAL-"><img src="https://img.shields.io/github/stars/Takashi-Kemii/Kiku.svg"</a>
<a href="https://github.com/rizkiwibu/IKY-BOT-WHATSAPP-OFFICIAL-"><img src="https://img.shields.io/github/forks/Takashi-Kemii/Kiku.svg"</a>
<a href="https://github.com/rizkiwibu/IKY-BOT-WHATSAPP-OFFICIAL-"><img src="https://img.shields.io/github/repo-size/Takashi-Kemii/Kiku.svg"></a>
<img src="https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png"/>

Bot chat WhatsApp adalah program kecerdasan buatan AI (artificial intelligence) yang dimiliki oleh WhatsApp Business API. Sistem bot ini mampu berperan sebagai asisten virtual yang membalas setiap pesan WhatsApp secara otomatis dalam hitungan detik.

<details close="close">
<summary>Bot Ini Dikembangkan Oleh <b>Rizki irfan</b></summary>
<a href="http://wa.me/6285878836361"><img src="https://img.shields.io/badge/Whatsapp-30302f?style=flat&logo=whatsapp"></a>
<a href="http://www.instagram.com/ikykunnnn"><img src="https://img.shields.io/badge/Instagram-30302f?style=flat&logo=instagram"></a>
</details><details close="close"><summary>Tutorial Menginstall <b>iky - bot</b></summary>

- `Select The Language`

`you can choose Indonesian or English`
<details close="close">
<summary><i><b>Indonesian</b></i></summary>

***
### 1. Install Aplikasi [Termux](https://f-droid.org/repo/com.termux_118.apk)
> Setelah Install Aplikasi Termux, Silahkan Salin Teks Dibawah, Setelah Disalin Tempel Di Aplikasi Termux.
```
pkg update -y;pkg upgrade -y;pkg install nodejs -y;pkg install git -y;git clone https://github.com/rizkiwibu/IKY-BOT-WHATSAPP-OFFICIAL-.git && cd nama sc;rm -rf session.json;node index
```
### 2. Pairing Code
> Setelah Menempel Nomer Kalian Ke Termux/Panel, Nanti Akan Muncul Code Pairingnya, Kalian Bisa Masukan Code Tersebut Di Whatsapp Kalian.
### 3. Catatan
> Saya Sarankan Jangan Menggunakan Whatsapp/Nomor Pribadi
***
</details><details close="close"><summary><i><b>English</b></i></summary>

***
### 1. Install The [Termux](https://f-droid.org/repo/com.termux_118.apk) App
> After Installing The Termux Application, Please Copy The Text Below, After Copying Paste In The Termux Application.
```
pkg update -y;pkg upgrade -y;pkg install nodejs -y;pkg install git -y;git clone https://github.com/rizkiwibu/IKY-BOT-WHATSAPP-OFFICIAL-.git && cd nama file;rm -rf session.json;node index
```
### 2. Pairing Code
> After pasting your number into Termux/Panel, the pairing code will appear, you can enter the code in your WhatsApp.
### 3. Note
> I Suggest Don't Use Whatsapp/Personal Number
***
</details></details>
<img src="https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png"/>

### Features
- [✅] Bug
- [✅] Buggc
- [✅] Jadibot pairing
- [✅] fitur ai banyak
- [✅] Ai voice hololive untuk meruba suara menjadi suara member idol hololive 
- [✅] Trade
- [✅] Sosmed
- [✅] GroupSetting
- [✅] Kick & Add
- [✅] Promote & Demote
- [✅] Chat & Call
- [✅] Public & Private
- [✅] Restart & Shutdown
- [ ] And others

### Changelogs
<details open="open"><summary>Added <b>New Features</b></summary>

```
. hololive (fitur voice perubahan suara)
.jadibot (numpang bot)
.ai (openai)
.bug (bug number)
.buggc (bug group)
.fix (fixed all error)
.trade (ongoing)
```
</details>
